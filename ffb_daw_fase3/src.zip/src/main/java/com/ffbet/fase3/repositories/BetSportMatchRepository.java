package com.ffbet.fase3.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ffbet.fase3.domain.BetSportMatch;

public interface BetSportMatchRepository extends JpaRepository<BetSportMatch, Long> {

}
