package com.ffbet.fase3.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ffbet.fase3.domain.Team;

public interface TeamRepository extends JpaRepository<Team, Long>{

}
